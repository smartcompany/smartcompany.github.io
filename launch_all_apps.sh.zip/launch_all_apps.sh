#!/usr/bin/env bash
set -euo pipefail

# Launch installed apps (with launcher activity) via ADB.
# Requires: USB debugging enabled and one Android device connected.
# Usage:
#   ./launch_all_apps.sh
#   ./launch_all_apps.sh --interval 2.0
#   ./launch_all_apps.sh --recent 20
#   ./launch_all_apps.sh --recent 10 --user-only

if ! command -v adb >/dev/null 2>&1; then
  echo "adb not found. Install Android platform-tools first."
  exit 1
fi

adb get-state >/dev/null

INTERVAL_SEC="1.2"
RECENT_N=""
USER_ONLY="0"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --interval)
      INTERVAL_SEC="${2:-}"
      shift 2
      ;;
    --recent)
      RECENT_N="${2:-}"
      shift 2
      ;;
    --user-only)
      USER_ONLY="1"
      shift
      ;;
    -h|--help)
      cat <<'EOF'
Usage:
  launch_all_apps.sh [--interval SEC] [--recent N] [--user-only]

Options:
  --interval SEC   Seconds between launches (default: 1.2)
  --recent N       Launch only N most recently installed packages
                   (sorted by firstInstallTime desc)
  --user-only      Use user-installed packages only (pm list packages -3)
EOF
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

if [[ -n "$RECENT_N" && ! "$RECENT_N" =~ ^[0-9]+$ ]]; then
  echo "--recent expects a positive integer"
  exit 1
fi

if [[ "$USER_ONLY" == "1" ]]; then
  PKG_CMD="pm list packages -3"
else
  PKG_CMD="pm list packages"
fi

echo "Starting app launch sweep (interval=${INTERVAL_SEC}s, recent=${RECENT_N:-all}, user_only=${USER_ONLY})..."

total=0
launchable=0
launched=0
skipped=0

build_pkg_stream() {
  if [[ -n "$RECENT_N" ]]; then
    # Build "timestamp<TAB>package" lines and keep top N by firstInstallTime desc.
    while IFS= read -r pkg; do
      [[ -z "$pkg" ]] && continue
      ts="$(
        adb shell dumpsys package "$pkg" </dev/null 2>/dev/null \
          | sed -n 's/.*firstInstallTime=//p' \
          | head -n 1
      )"
      # Normalize "YYYY-MM-DD HH:MM:SS" -> "YYYY-MM-DDTHH:MM:SS" for date parsing.
      epoch="$(
        date -j -f "%Y-%m-%d %H:%M:%S" "$ts" "+%s" 2>/dev/null || echo 0
      )"
      printf "%s\t%s\n" "$epoch" "$pkg"
    done < <(adb shell "$PKG_CMD" | sed 's/^package://' | tr -d '\r') \
      | sort -nr -k1,1 \
      | head -n "$RECENT_N" \
      | cut -f2
  else
    adb shell "$PKG_CMD" | sed 's/^package://' | tr -d '\r'
  fi
}

while IFS= read -r pkg; do
  [ -z "$pkg" ] && continue
  total=$((total + 1))

  # Find launcher activity for package (if any).
  activity="$(
    adb shell cmd package resolve-activity --brief "$pkg" </dev/null 2>/dev/null \
      | tr -d '\r' \
      | tail -n 1
  )"
  if [ -z "$activity" ] || [ "$activity" = "No activity found" ] || [[ "$activity" != */* ]]; then
    skipped=$((skipped + 1))
    continue
  fi

  launchable=$((launchable + 1))
  echo "[$launchable] Launching: $activity"
  if adb shell am start -n "$activity" </dev/null >/dev/null 2>&1; then
    launched=$((launched + 1))
  fi

  # Keep transitions visible.
  sleep "$INTERVAL_SEC"
done < <(build_pkg_stream)

echo "Done. total=$total launchable=$launchable launched=$launched skipped=$skipped"
